      document.getElementById("generalformBtn").addEventListener("click", function () {
    document.getElementById("general").scrollIntoView({
      behavior: "smooth",
      block: "start"
    });
  });

        document.getElementById("validationformBtn").addEventListener("click", function () {
    document.getElementById("validation").scrollIntoView({
      behavior: "smooth",
      block: "start"
    });
  });