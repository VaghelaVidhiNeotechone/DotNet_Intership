function showToast(message, field = null, type = "danger") {
  const container = document.getElementById("toastContainer");
  const toast = document.createElement("div");
  toast.className = `toast align-items-center text-bg-${type.toLowerCase()} border-0 mb-2`;
  toast.role = "toast";
  toast.innerHTML = `
    <div class="d-flex">
      <div class="toast-body">${message}</div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
    </div>`;
  container.appendChild(toast);
  const bsToast = new bootstrap.Toast(toast, { delay: 3000 });
  bsToast.show();
  toast.addEventListener("hidden.bs.toast", () => toast.remove());
  if (field) field.focus();
}

const loginForm = document.getElementById("loginForm");
if (loginForm) {
  const luser = document.getElementById("loginUsername");
  const lpass = document.getElementById("loginPassword");

  loginForm.addEventListener("submit", function (e) {
    e.preventDefault();

    const nameRegex = /^[A-Za-z]+(?:\s[A-Za-z]+)*$/;
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!(nameRegex.test(luser.value.trim()) || emailRegex.test(luser.value.trim()))) {
      return showToast("Enter a valid username (letters only) or a valid email.", luser);
    }

    if (lpass.value.trim().length < 6) {
      return showToast("Password must be at least 6 characters long.", lpass);
    }

    showToast("Login Successful!", null, "success");
    setTimeout(() => (window.location.href = "homeboot.html"), 1500);
  });
}



    const locationData = {
      india: { gujarat: ["Ahmedabad", "Rajkot"], kerala: ["Kochi", "Trivandrum"] },
      brazil: { acre: ["Rio Branco"], amazonas: ["Manaus"] },
      us: { victoria: ["Melbourne", "Ballarat"], tasmania: ["Hobart", "Burnie"] }
    };

    const country = document.getElementById("country");
    const state = document.getElementById("state");
    const city = document.getElementById("city");
    const phone = document.getElementById("phone");
//when user can select satate use this function
    country.addEventListener("change", () => {
      state.innerHTML = '<option selected disabled>Select State</option>';
      city.innerHTML = '<option selected disabled>Select City</option>';
      const states = Object.keys(locationData[country.value]);
      states.forEach(s => state.innerHTML += `<option value="${s}">${s}</option>`);

      if (country.value === "india")
         phone.value = "+91 ";
      else if (country.value === "brazil")
         phone.value = "+55 ";
      else if (country.value === "us")
         phone.value = "+61 ";
      else
         phone.value = "";
    });

    state.addEventListener("change", () => {
      city.innerHTML = '<option selected disabled>Select City</option>';
      const cities = locationData[country.value][state.value];
      cities.forEach(c => city.innerHTML += `<option value="${c}">${c}</option>`);
    });

    const photoInput = document.getElementById("photo");
    const preview = document.getElementById("preview");
    photoInput.addEventListener("change", () => {
      if (photoInput.files.length > 0) {
        //temporary file URL
        preview.src = URL.createObjectURL(photoInput.files[0]);
        preview.classList.remove("d-none");
      } else {
        preview.classList.add("d-none");
      }
    });

    // Form Validation
    document.getElementById("regForm").addEventListener("submit", function (e) {
      e.preventDefault();

      const fname = document.getElementById("firstName");
      const lname = document.getElementById("lastName");
      const email = document.getElementById("email");
      const pass = document.getElementById("password");
      const cpass = document.getElementById("confirmPassword");
      const address = document.getElementById("address");
      const website = document.getElementById("website");
      const dob = document.getElementById("dob");
      const ctime = document.getElementById("contacttime");
      const bmonth = document.getElementById("birthmonth");
      const photo = document.getElementById("photo");
      const hobbies = document.querySelectorAll(".hobby:checked");
      const genders = document.querySelectorAll(".gender:checked");

      //reguler Expression
      const nameRegex = /^[A-Za-z]{2,}$/;
      //first name
      if (!fname.value.trim())
        return showToast("Please Enter First Name",fname);
      if (!nameRegex.test(fname.value.trim()))
        return showToast("First name must contain only letters.",fname);


      //last name
      if (!lname.value.trim())
        return showToast("Please Enter Last Name",lname);
      if (!nameRegex.test(lname.value.trim()))
        return showToast("Last Name must contain only letters.",lname);

       //email address
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
      if (!email.value.trim())
        return showToast("Please Enter Your Email Address",email);
      if (!emailRegex.test(email.value) || !email.value.includes(".com"))
        return showToast("Enter a valid email (must include @ and .com).",email);

       //password
      if (!pass.value.trim())
        return showToast("Please Enter Password",pass);
      if (pass.value.length < 6)
        return showToast("Password must be at least 6 characters.",pass);
      if (pass.value !== cpass.value)
        return showToast("Passwords do not match.",cpass);

       //gender
      if (genders.length === 0)
        return showToast("Please select gender.");

       //address
      if (!address.value.trim())
        return showToast("Please enter your address.",address);

       //country
      if (country.value === "Select Country")
        return showToast("Please select a country.",country);

       //state
      if (state.value === "Select State")
        return showToast("Please select a state.",state);

       //city
      if (city.value === "Select City")
        return showToast("Please select a city.",city);

       //phone
      const phoneRegex = /^\+(91|55|61)\s[0-9]{10}$/;
      if (["+", "+91", "+55", "+61"].includes(phone.value.trim()))
        return showToast("Please Enter Phone Number",phone);
      if (!phoneRegex.test(phone.value))
        return showToast("Enter a valid 10-digit phone number.",phone);

     // DOB
      const today = new Date().toISOString().split("T")[0];
      dob.max = today;
      if (!dob.value) {
        return showToast("Select a valid date of birth", dob);
      } else if (dob.value > today) {
        return showToast("Date of birth cannot be in the future", dob);
      } else {
        dob.classList.remove("is-invalid");
      }
   

       //Url
      if (!website.value.startsWith("http"))
        return showToast("Enter a valid website URL (must start with http).",website);

       //Contact time
      if (!ctime.value)
        return showToast("Enter a valid contact time.",ctime);

       //birth month
      if (!bmonth.value)
        return showToast("Enter a valid birth month.",bmonth);

       //hobbies
      if (hobbies.length === 0)
        return showToast("Select at least one hobby.");

       //photo
      if (!photo.value)
        return showToast("Please upload a photo.",photo);

      // Success
      showToast("Registration Successful!", null, "success");
setTimeout(() => window.location.href = "ShowToast.html", 2000);
    });
