 const loginForm = document.getElementById("loginForm");
  const luser = document.getElementById("loginUsername");
  const lpass = document.getElementById("loginPassword");

  loginForm.addEventListener("submit", function (e) {
    e.preventDefault(); 
    let valid = true;

    const nameRegex = /^[A-Za-z]+(?:\s[A-Za-z]+)*$/; 
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    // Username or Email 
    if (!(nameRegex.test(luser.value.trim()) || emailRegex.test(luser.value.trim()))) {
      luser.focus();
      luser.classList.add("is-invalid");
      valid = false;
    } else {
      luser.classList.remove("is-invalid");
    }

    // Password 
    if (lpass.value.trim().length < 6) {
      lpass.focus();
      lpass.classList.add("is-invalid");
      valid = false;
    } else {
      lpass.classList.remove("is-invalid");
    }
    if (valid) {
      loginForm.submit();
    }
  });


//object
const locationData = {
  india: { gujarat: ["Ahmedabad", "Rajkot"], kerala: ["Kochi", "Trivandrum"] },
  brazil: { acre: ["Rio Branco"], amazonas: ["Manaus"] },
  us: { victoria: ["Melbourne", "Ballarat"], tasmania: ["Hobart", "Burnie"] }
};
//variable
const country = document.getElementById("country");
const state = document.getElementById("state");
const city = document.getElementById("city");
const phone = document.getElementById("phone");

// Country -> State -> City -> Phone Code
//when user can select state use this fuction
country.addEventListener("change", () => {
  state.innerHTML = '<option selected disabled>Select State</option>';
  city.innerHTML = '<option selected disabled>Select City</option>';
  const states = Object.keys(locationData[country.value] || {});
  states.forEach(s => state.innerHTML += `<option value="${s}">${s}</option>`);

  if (country.value === "india")
    phone.value = "+91 ";
  else if (country.value === "brazil") 
    phone.value = "+55 ";
  else if (country.value === "us")
    phone.value = "+61 ";
  else
    phone.value = "";
});

state.addEventListener("change", () => {
  city.innerHTML = '<option selected disabled>Select City</option>';
  const cities = (locationData[country.value] || {})[state.value] || [];
  cities.forEach(c => city.innerHTML += `<option value="${c}">${c}</option>`);
});

// Photo Preview
const photoInput = document.getElementById("photo");
const preview = document.getElementById("preview");
photoInput.addEventListener("change", () => {
  if (photoInput.files.length > 0) {
      preview.src = URL.createObjectURL(photoInput.files[0]);
      preview.classList.remove("d-none");
    photoInput.classList.remove("is-invalid");
  } else {
    
    preview.classList.add("d-none");
    photoInput.classList.add("is-invalid");
  }
});

// Form Validation
document.getElementById("regForm").addEventListener("submit", function (e) {
  e.preventDefault();
  let valid = true;

  const fname = document.getElementById("firstName");
  const lname = document.getElementById("lastName");
  const email = document.getElementById("email");
  const pass = document.getElementById("password");
  const cpass = document.getElementById("confirmPassword");
  const address = document.getElementById("address");
  const website = document.getElementById("website");
  const dob = document.getElementById("dob");
  const ctime = document.getElementById("contactTime");
  const bmonth = document.getElementById("birthMonth");
  const search = document.getElementById("searches");
  const photo = document.getElementById("photo");
  const hobbies = document.querySelectorAll(".hobby");
  const checkedHobbies = document.querySelectorAll(".hobby:checked");
  const genders = document.querySelectorAll(".gender");
  const checkedGender = document.querySelectorAll(".gender:checked");



  // First Name
  const nameRegex = /^[A-Za-z]{2,}$/;
  if (!nameRegex.test(fname.value.trim())) {
    fname.focus();
    fname.classList.add("is-invalid"); valid = false;
  } else {
    fname.classList.remove("is-invalid");
  }

  // Last Name
  if (!nameRegex.test(lname.value.trim())) {
    lname.focus();
    lname.classList.add("is-invalid"); valid = false;
  } else {
    lname.classList.remove("is-invalid");
  }

  // Email
  //reguler Expression
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  if (!emailRegex.test(email.value) || !email.value.includes(".com")) {
    email.focus();
    email.classList.add("is-invalid"); valid = false;
  } else {
    email.classList.remove("is-invalid");
  }

  // Password
  if (pass.value.length < 6) {
    pass.focus();
    pass.classList.add("is-invalid"); valid = false;
  } else {
    pass.classList.remove("is-invalid");
  }

  // Confirm Password
  if (pass.value !== cpass.value || !cpass.value) {
    cpass.focus();
    cpass.classList.add("is-invalid"); valid = false;
  } else {
    cpass.classList.remove("is-invalid");
  }

  // Gender
 if (checkedGender.length === 0) {
  
  genders.forEach(g => g.classList.add("is-invalid"));
  genderError.style.display = "block"; 
  valid = false;
} else {
  genders.forEach(g => g.classList.remove("is-invalid"));
  genderError.style.display = "none";
}
  // Address
  if (!address.value.trim()) {
    address.focus();
    address.classList.add("is-invalid"); valid = false;
  } else {
    address.classList.remove("is-invalid");
  }

  // Country
  if (!country.value || country.value === "Select Country") {
    country.focus();
    country.classList.add("is-invalid"); valid = false;
  } else {
    country.classList.remove("is-invalid");
  }

  // State
  if (!state.value || state.value === "Select State") {
    state.focus();
    state.classList.add("is-invalid"); valid = false;
  } else {
    state.classList.remove("is-invalid");
  }

  // City
  if (!city.value || city.value === "Select City") {
    city.focus();
    city.classList.add("is-invalid"); valid = false;
  } else {
    city.classList.remove("is-invalid");
  }

  // Phone
  const phoneRegex = /^\+(91|55|61)\s[0-9]{10}$/;
  if (!phoneRegex.test(phone.value.trim())) {
    phone.focus();
    phone.classList.add("is-invalid"); valid = false;
  } else {
    phone.classList.remove("is-invalid");
  }

// DOB
const today = new Date().toISOString().split("T")[0];
dob.max = today;

if (!dob.value) {
  dob.focus();
  dob.classList.add("is-invalid");
  valid = false;
} else if (dob.value > today) {
  dob.classList.add("is-invalid");
  valid = false;
} else {
  dob.classList.remove("is-invalid");
}

  // Website
  if (!website.value.startsWith("http")) {
    website.focus();
    website.classList.add("is-invalid"); valid = false;
  } else {
    website.classList.remove("is-invalid");
  }

  // Contact Time
  if (!ctime.value) {
    ctime.focus();
    ctime.classList.add("is-invalid"); valid = false;
  } else {
    ctime.classList.remove("is-invalid");
  }

  // Birth Month
  if (!bmonth.value) {
    bmonth.focus();
    bmonth.classList.add("is-invalid"); valid = false;
  } else {
    bmonth.classList.remove("is-invalid");
  }

  // Search
  if (!search.value.trim()) {
    search.focus();
    search.classList.add("is-invalid"); valid = false;
  } else {
    search.classList.remove("is-invalid");
  }

  // Hobbies
 
if (checkedHobbies.length === 0) {
  hobbies.forEach(h => h.classList.add("is-invalid"));
  hobbiesError.style.display = "block";  
  valid = false;
} else {
  hobbies.forEach(h => h.classList.remove("is-invalid"));
  hobbiesError.style.display = "none";   }

  // Photo
  if (!photo.files.length) {
    photo.focus();
    photo.classList.add("is-invalid"); valid = false;
  } else {
    photo.classList.remove("is-invalid");
  }

  // Final Submit
  if (valid) {
    window.location.href = "ErrorMsg.html";
  }
});
