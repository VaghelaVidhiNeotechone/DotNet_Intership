    const loginForm = document.getElementById("loginForm");
  const luser = document.getElementById("loginUsername");
  const lpass = document.getElementById("loginPassword");

  loginForm.addEventListener("submit", function (e) {
    e.preventDefault(); 
    let valid = true;

    const nameRegex = /^[A-Za-z]+(?:\s[A-Za-z]+)*$/; 
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    // Username or Email 
    if (!(nameRegex.test(luser.value.trim()) || emailRegex.test(luser.value.trim()))) {
      luser.classList.add("is-invalid");
      valid = false;
    } else {
      luser.classList.remove("is-invalid");
    }

    // Password 
    if (lpass.value.trim().length < 6) {
      lpass.classList.add("is-invalid");
      valid = false;
    } else {
      lpass.classList.remove("is-invalid");
    }
    if (valid) {
      loginForm.submit();
    }
  });
   
   const locationData = {
      india: { gujarat: ["Ahmedabad", "Rajkot"], kerala: ["Kochi", "Trivandrum"] },
      brazil: { acre: ["Rio Branco"], amazonas: ["Manaus"] },
      us: { victoria: ["Melbourne", "Ballarat"], tasmania: ["Hobart", "Burnie"] }
    };

    const country = document.getElementById("country");
    const state = document.getElementById("state");
    const city = document.getElementById("city");
    const phone = document.getElementById("phone");

    country.addEventListener("change", () => {
      state.innerHTML = '<option selected disabled>Select State</option>';
      city.innerHTML = '<option selected disabled>Select City</option>';
      const states = Object.keys(locationData[country.value]);
      states.forEach(s => state.innerHTML += `<option value="${s}">${s}</option>`);

      if (country.value === "india")
         phone.value = "+91 ";
      else if (country.value === "brazil")
         phone.value = "+55 ";
      else if (country.value === "us")
         phone.value = "+61 ";
      else
         phone.value = "";
    });

    state.addEventListener("change", () => {
      city.innerHTML = '<option selected disabled>Select City</option>';
      const cities = locationData[country.value][state.value];
      cities.forEach(c => city.innerHTML += `<option value="${c}">${c}</option>`);
    });

    const photoInput = document.getElementById("photo");
    const preview = document.getElementById("preview");
    photoInput.addEventListener("change", () => {
      if (photoInput.files.length > 0) {
        preview.src = URL.createObjectURL(photoInput.files[0]);
        preview.classList.remove("d-none");
        photoInput.classList.remove("is-invalid");
      } else {
        preview.classList.add("d-none");
        photoInput.classList.add("is-invalid");
      }
    });

    // Form Validation
    document.getElementById("regForm").addEventListener("submit", function (e) {
      e.preventDefault();
      let valid = true;

      const fname = document.getElementById("firstName");
      const lname = document.getElementById("lastName");
      const email = document.getElementById("email");
      const pass = document.getElementById("password");
      const cpass = document.getElementById("confirmPassword");
      const address = document.getElementById("address");
      const website = document.getElementById("website");
      const dob = document.getElementById("dob");
      const ctime=document.getElementById("contacttime");
      const bmonth=document.getElementById("birthmonth");
     // const satisfaction=document.getElementById("satisfactionRange");
     const search=document.getElementById("searches"); 
      const photo = document.getElementById("photo");
      const hobbies = document.querySelectorAll(".hobby");
      const checkedHobbies = document.querySelectorAll(".hobby:checked");
      const genders = document.querySelectorAll(".gender");
      const checkedGender = document.querySelectorAll(".gender:checked");

      //fname,lname
      const nameRegex = /^[A-Za-z]{2,}$/;
      if (!nameRegex.test(fname.value.trim())) { 
        fname.focus();
        fname.classList.add("is-invalid"); valid = false;
       } 
       else {
         fname.classList.remove("is-invalid");
         }
      if (!nameRegex.test(lname.value.trim())) {
         lname.focus();
         lname.classList.add("is-invalid"); valid = false;
         }
          else { 
          lname.classList.remove("is-invalid");
         }

         //email
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
      if (!emailRegex.test(email.value) || !email.value.includes(".com")) {
         email.focus();
         email.classList.add("is-invalid"); valid = false; 
        } 
        else {
           email.classList.remove("is-invalid"); 
          }

          //pass,confirmpass
      if (pass.value.length < 6) { 
        pass.focus();
        pass.classList.add("is-invalid"); valid = false; 
      }
       else { 
        pass.classList.remove("is-invalid"); 
      }
      if (pass.value !== cpass.value || !cpass.value) { 
        cpass.focus();
        cpass.classList.add("is-invalid"); valid = false;
       }
        else {
         cpass.classList.remove("is-invalid");
         }

         //gender
      if (checkedGender.length === 0) {
         genders.forEach(g => g.classList.add("is-invalid")); valid = false;
         }
          else { 
          genders.forEach(g => g.classList.remove("is-invalid"));
         }

         //address
      if (!address.value.trim()) {
        address.focus();
        address.classList.add("is-invalid"); valid = false;
       } 
       else {
         address.classList.remove("is-invalid");
         }

         //country
      if (country.value === "Select Country") {
        country.focus();
         country.classList.add("is-invalid"); valid = false;
         }
          else { 
          country.classList.remove("is-invalid");
         }

         //state
      if (state.value === "Select State") {
         state.focus();
         state.classList.add("is-invalid"); valid = false;
         } 
         else { 
          state.classList.remove("is-invalid");
         }

         //city
      if (city.value === "Select City") {
         city.focus();
         city.classList.add("is-invalid"); valid = false; 
        }
         else { 
          city.classList.remove("is-invalid"); 
        }

        //phone
      const phoneRegex = /^\+(91|55|61)\s[0-9]{10}$/;
      if (!phoneRegex.test(phone.value)) {
         phone.focus();
         phone.classList.add("is-invalid"); valid = false;
         } 
         else {
           phone.classList.remove("is-invalid");
           }


      // DOB
         const today = new Date().toISOString().split("T")[0];
      dob.max = today;
      if (!dob.value) {
        dob.classList.add("is-invalid");
        valid = false;
      } else if (dob.value > today) {
        dob.classList.add("is-invalid");
        valid = false;
      } else {
        dob.classList.remove("is-invalid");
      }

      //Url
      if (!website.value.startsWith("http")) { 
        website.focus();
        website.classList.add("is-invalid"); valid = false;
       }
        else { 
        website.classList.remove("is-invalid");
       }

       //ctime
      if(!ctime.value){
        ctime.focus();
        ctime.classList.add("is-invalid");valid=false;
      }
      else{
        ctime.classList.remove("is-invalid");
      }

      //bmonth
      if(!bmonth.value){
        bmonth.focus();
        bmonth.classList.add("is-invalid"); valid=false;
      }
      else{
        bmonth.classList.remove("is-invalid");
      }


//      if(!satisfaction.value){
//        satisfaction.classList.add("is-invalid");valid=false;
//      }else{
//        satisfaction.classList.remove("is-invalid");
//      }


    //search
      if(!search.value){
        search.focus();
        search.classList.add("is-invalid");
      }
      else{
        search.classList.remove("is-invalid");
      }

      //hobbies
      if (checkedHobbies.length === 0) {
        hobbies.forEach(h => h.classList.add("is-invalid"));
        valid = false;
      } else {
        hobbies.forEach(h => h.classList.remove("is-invalid"));
      }


         //upload PHoto
      if (!photo.value) { 
        photo.focus();
        photo.classList.add("is-invalid"); valid = false; 
      } 
      else {
         photo.classList.remove("is-invalid");
         }


      if (valid) 
        { window.location.href="ExclamationMark.html" }
    });
 
